import boto3
import pymysql
from datetime import datetime, timedelta

# Configuración de AWS y base de datos
s3 = boto3.client('s3')
db_config = {
    'host': 'db-blog.clk8is2ku4cp.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'admin123',
    'database': 'blog_personal'
}

BUCKET_NAME = "blog-imagenes-users"  # Cambia esto por tu bucket de S3
RETENTION_DAYS = 1  # Tiempo en días para considerar una publicación como "inactiva"


def lambda_handler(event, context):
    # Conexión a la base de datos
    connection = pymysql.connect(**db_config)
    cursor = connection.cursor()
    
    # Calcular el límite de retención
    retention_limit = datetime.now() - timedelta(days=RETENTION_DAYS)
    
    # Query para seleccionar publicaciones que exceden el límite
    query = """
    SELECT post_id, image_url 
    FROM posts 
    WHERE created_at < %s
    """
    cursor.execute(query, (retention_limit,))
    rows = cursor.fetchall()
    
    # Procesar publicaciones para eliminar
    for row in rows:
        post_id, image_url = row
        print(f"Eliminando publicación ID {post_id} y archivo {image_url}")
        
        # Obtener el nombre del archivo en S3 desde la URL
        file_key = image_url.replace(f"https://{BUCKET_NAME}/", "")  # Ajusta si la URL tiene un formato diferente
        
        # Eliminar archivo de S3
        try:
            s3.delete_object(Bucket=BUCKET_NAME, Key=file_key)
            print(f"Archivo {file_key} eliminado de S3.")
        except Exception as e:
            print(f"Error al eliminar archivo {file_key}: {e}")
        
        # Eliminar publicación de la base de datos
        delete_query = "DELETE FROM posts WHERE post_id = %s"
        cursor.execute(delete_query, (post_id,))
        print(f"Publicación ID {post_id} eliminada de la base de datos.")
    
    # Confirmar cambios en la base de datos
    connection.commit()
    cursor.close()
    connection.close()
    print("Proceso de limpieza completado.")
